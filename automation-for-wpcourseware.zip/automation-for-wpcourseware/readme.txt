=== Automation for WPCourseware ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: Automation, WPCourseware, Flowmattic
Requires at least: 6.5
Tested up to: 6.8.2
Stable tag: 1.3.4
Requires PHP: 8.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin to allow you to easily add or remove users from courses

== Description ==
A plugin to allow you to easily add or remove users from courses

== Installation ==

1. Upload the `automation-for-wpcourseware` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Its now ready to use

== Frequently Asked Questions ==

= How do I add use the plugin? =
You need to call the required functions in Flowmattic as needed

 
== Changelog == 
= 1.3.4 2 Aug 2025 =
New: MainWP Icon Filter

= 1.3.3 27 July 2025 =
New: Prepare Future Support for Preleases
New: Updated UUPD to 1.3.0


= 1.3.2 14 July 2025 =
Update: UUPD 1.2.5

= 1.3.1 06 July 2025 =
New: Rescoped RUP_UUPD
Update: UUPD 1.2.4

= 1.3 21 June 2025 =
New: Updates Now served directly from GitHub using UUPD

= 1.1.3 16 June 2025 =
Tweak: Updater Script - 1.2.3

= 1.2 (10 April 2025) = 
New: Rest API (Enrol and Remove User)
New: Webhook Triggers for Unit Complete, Module Complete, Course Complete and Enrolled on Course
New: Web Hook Authorisation
New: Admin Interface

= 1.1 (7 April 2025) =
New: Added Custom Trigger Function - User Completed Unit
New: Added Custom Trigger Function - User Completed Module
New: Added Custom Trigger Function - User Completed Course
New: Added Custom Trigger Function - User Enrolled on Course

= 1.0 (5 April 2025) =
New: Initial Release
New: Auto Update
New: Add and Remove user from Course functions