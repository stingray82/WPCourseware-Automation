=== dashy for surecart ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: dashboard, tabs, surecart, custom icons, shortcode
Requires at least: 
Tested up to: 
Stable tag: 
Requires PHP: 
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
A plugin to allow you to easily add or remove users from courses

== Installation ==
1. Upload the `automation-for-wpcourseware` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Its now ready to use

== Frequently Asked Questions ==
= How do I add use the plugin? =
You need to call the required functions in Flowmattic as needed


== Changelog ==
= 1.07 (27 March 2025) =
Improved: Fuzziness in naming conventions of changelog headers

= 1.06 (25 March 2025) =
New: Added Some Fuzziness to the interpretation of headers and words including common used like improved and improvement, Warn and Warning, Update and Updated

= 1.05 (24 March 2025) =
Tweaked: Stylesheet Filter for better override
Tweaked: Updater Location

= 1.04 (21 March 2025) =
Tweaked: Updater Settings

= 1.03 (21 March 2025) =
Tweaked: URL Cache Clear to only run if present not every page load

= 1.02 (20 March 2025) =
Fixed: CSS Tweak - Timeline boarder removed on smaller screen for cleaner look
Fixed: Toolbar Cache Clear not looking for new URL based transient

= 1.01 (20 March 2025) =
New: Added Automatic Updates

= 1.0 (19 March 2025) =
New: Initial Release
New: Filter CSS
New: Filter Tag Colour
New: Filter Secret Key